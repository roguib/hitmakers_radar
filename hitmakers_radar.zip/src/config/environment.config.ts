/*
    Read https://stackoverflow.com/questions/25276540/stop-tracking-files-in-git-without-deleting-them
    if we need to make changes to the file and track them. Remember to delete all credentials before
    adding the file again
*/
// TODO: Replace this json file for an env file
export const CONFIG_OPTIONS = {
    twitter_api: {
        base_url: "https://api.twitter.com",
        token: "Bearer AAAAAAAAAAAAAAAAAAAAAAndGwEAAAAAxhedA%2F9HWn11tl%2Fp02%2BcKz8%2Bhcs%3DcoeYqphB1dcFmJoZAvsSVuMBYfUY1ZDg8Q7M6Isx28bnWLxH1z",
        consumer_key: "htUHQS5IK1gnfH0ugWOymxI7Y",
        consumer_secret: "UV9nLAuFV9WppiUebbyXMGY2hX0jaRMxYWKsXyJbByvpZW8WD1",
        access_token_key: "1296800967120297984-8s8ICW6raS8LjmI88e9BSdSwfhVbTY",
        access_token_secret: "cT46it3ASmfdSN0ZExpSNfyHq5q1qKafVbg3np4y6XWKp"
    },
    database: {
        url: 'mongo',
        port: '27017',
        auth: {
            user: '',
            password: ''
        }
    },
}