// TODO: Remove camel case names
export interface User {
    id: string;
    name: string;
    screen_name: string;
}